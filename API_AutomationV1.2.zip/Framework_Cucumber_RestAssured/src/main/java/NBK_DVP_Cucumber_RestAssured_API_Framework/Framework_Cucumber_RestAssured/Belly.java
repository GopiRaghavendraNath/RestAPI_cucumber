package NBK_DVP_Cucumber_RestAssured_API_Framework.Framework_Cucumber_RestAssured;

public class Belly {
    public void eat(int cukes) {

    }
}
